# Frame It
A fun puzzle game to play with 2 people. Organize your 5x5 play grid to make the middle 3x3 tiles or your grip the same as the solutions 3x3 grid (between the two playable grids).
Use W A S D keys for player 1 and the arrow keys for player two. The first to match their middle 3x3 tiles to the solutions tiles wins! Now with improved freatures!... Save the game if you 
you are too busy to finish the last 15 seconds, and load that very same game anytime you want! Just hit save, exit the game, open it back up, hit load, then play,
and aaaaaaawaaaaaaaaaaaaay you go. Dont forget to have fun.

# To Play
If the file has not yet been compiled then in cmd go into the FrameIt folder you have created by extracting the zip file and type "javac -d . *.java". once it has completed compiling type "java Start.Driver"
and enjoy our game Frame It.

# Credits
Made by group 40, part of the U of C 2017 winter semester CPSC 233 Lo2 class's semester project.

Group 40:

Programmers

Zachary Hull     
Justin Desrochers     
JC Sicat     
William Kang

No other positions.